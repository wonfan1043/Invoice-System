CREATE TABLE `topic` (
  `topic_id` varchar(20) NOT NULL,
  `topic_name` varchar(20) NOT NULL,
  `comment` varchar(50) DEFAULT NULL,
  `creater` varchar(20) NOT NULL,
  `create_datetime` datetime NOT NULL,
  `updater` varchar(20) DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `delete` tinyint DEFAULT '0',
  PRIMARY KEY (`topic_id`),
  UNIQUE KEY `topic_name_UNIQUE` (`topic_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
