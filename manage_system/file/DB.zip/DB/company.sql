CREATE TABLE `company` (
  `corp_id` int NOT NULL DEFAULT '0',
  `corp_en` varchar(20) NOT NULL,
  `corp_jp` varchar(20) NOT NULL,
  `corp_ch` varchar(20) NOT NULL,
  `founded_date` date DEFAULT NULL,
  `fund` int DEFAULT '0',
  `website` varchar(50) DEFAULT NULL,
  `ceo` varchar(10) DEFAULT NULL,
  `service_content` varchar(200) DEFAULT NULL,
  `inquiry_mail` varchar(30) DEFAULT NULL,
  `career_mail` varchar(30) DEFAULT NULL,
  `invoice_mail` varchar(30) DEFAULT NULL,
  `memo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`corp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
