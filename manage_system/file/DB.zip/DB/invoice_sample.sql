CREATE TABLE `invoice_sample` (
  `corp_name` varchar(20) NOT NULL,
  `receiver` varchar(20) NOT NULL,
  `postcode` varchar(10) NOT NULL,
  `county` varchar(20) NOT NULL,
  `town` varchar(20) NOT NULL,
  `address` varchar(45) NOT NULL,
  `building` varchar(45) DEFAULT NULL,
  `topic_name` varchar(45) NOT NULL,
  `bank_id` int NOT NULL,
  `tax` float NOT NULL,
  `creator` varchar(20) NOT NULL,
  `create_datetime` datetime NOT NULL,
  `updater` varchar(20) DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `delete` tinyint DEFAULT '0',
  PRIMARY KEY (`corp_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
