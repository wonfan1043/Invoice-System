CREATE TABLE `charge_content` (
  `invoice_no` varchar(9) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `quantity` int DEFAULT '0',
  `unit_price` bigint DEFAULT '0',
  `creator` varchar(20) NOT NULL,
  `create_datetime` datetime DEFAULT NULL,
  `updater` varchar(20) DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `delete` tinyint DEFAULT '0',
  PRIMARY KEY (`invoice_no`,`item_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
