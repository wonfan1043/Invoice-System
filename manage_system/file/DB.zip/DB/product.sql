CREATE TABLE `product` (
  `item_id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(20) NOT NULL,
  `sub_category` varchar(20) NOT NULL,
  `item_name` varchar(20) NOT NULL,
  `origin_price` int DEFAULT '0',
  `creator` varchar(20) NOT NULL,
  `create_time` datetime NOT NULL,
  `updater` varchar(20) DEFAULT NULL,
  `update_datetime` datetime DEFAULT NULL,
  `delete` tinyint DEFAULT '0',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `category_UNIQUE` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
